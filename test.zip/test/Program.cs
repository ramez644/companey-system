using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using test.Models;
using test.Repository;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddSession();


// Configure the HTTP request pipeline.



//custom middle ware
#region custom middle ware"end"
/*app.Use(async (HttpContext, next) =>
{
    //write response
   await HttpContext.Response.WriteAsync("1)Middle Ware 1\n");
    await next.Invoke();
    await HttpContext.Response.WriteAsync("5)Middle Ware 1\n");

});


app.Use(async (HttpContext, next) =>
{
    //write response
    await HttpContext.Response.WriteAsync("2)Middle Ware 2\n");
    await next.Invoke();
    await HttpContext.Response.WriteAsync("4)Middle Ware 2\n");

});

//terminate
app.Run(async (httpContext) =>
{
    await httpContext.Response.WriteAsync("3)Terminate\n");


});*/

#endregion 



// built in component
//add services to the cintainer "register"
//1- built in servicesand already registr in ioc container"iconguration"
//2- built in services but not register in ioc container "Addsession"
builder.Services.AddControllersWithViews(
    //conf=>conf.Filters.Add()//pieline filter works at any action
    );
builder.Services.AddSession(conf =>
{
    conf.IdleTimeout = TimeSpan.FromSeconds(20);
});

builder.Services.AddDbContext<Entity>(optionBuilder => {
    optionBuilder.UseSqlServer(builder.Configuration.GetConnectionString("cs"));
    
    });

builder.Services.AddIdentity<ApplicationUser, IdentityRole>()
    .AddEntityFrameworkStores<Entity>();

//3 custom services "register type single tansi-scope"
//transient creatin many object even if its in the same request
//singelton create one object 


builder.Services.AddScoped<IEmployeeRepository, EmployeeRepository>();
builder.Services.AddScoped<IDepartmentRepository, DepartmentRepository>();
//var ap = builder.Build();
var app = builder.Build();




if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();
app.UseSession();

app.MapControllerRoute("Route1",
    //literal 
    "emp/{id:int}", new
    {
        controller="Employee",
        action="Details"
    }
    
    
    );

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}/{name?}");

app.Run();
