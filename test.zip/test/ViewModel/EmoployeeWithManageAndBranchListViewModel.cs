﻿namespace test.ViewModel
{
    public class EmoployeeWithManageAndBranchListViewModel
    {
        public string Message { get; set; }
        public List<string> Branches { get; set; }

        public int Temp { get; set; }
        public string Color { get; set; }
        public string EmpName { get; set; }  
        public int EmpId { get; set; }   
    }
}
