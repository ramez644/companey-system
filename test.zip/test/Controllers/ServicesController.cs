﻿using Microsoft.AspNetCore.Mvc;
using test.Filters;
using test.Repository;
namespace test.Controllers
{
    public class ServicesController : Controller
    {
        [MyFilter]
        public IActionResult testFilter()
        {
            return Content("hi");
        }

        IEmployeeRepository EmpRepo;
        private readonly IConfiguration config;

        public ServicesController(IEmployeeRepository empRepo,IConfiguration config)
        {
            EmpRepo = empRepo;
            this.config = config;
        }
        public IActionResult Index()
        {

            string Name=config.GetSection("ProjectName").Value;
            ViewBag.ID = EmpRepo.Id;
            return View();
        }
    }
}
