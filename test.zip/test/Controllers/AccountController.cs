﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using test.Models;
using test.ViewModel;

namespace test.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;

        public AccountController(UserManager<ApplicationUser> userManager) {
            this.userManager = userManager;
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View("");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterUserViewModel newUserVM)
        {
            if (ModelState.IsValid)
            {
//mapping
            ApplicationUser userModel = new ApplicationUser();
                userModel.UserName = newUserVM.UserName;
                userModel.Address = newUserVM.Address;
                userModel.PasswordHash = newUserVM.Password;
               IdentityResult result=await userManager.CreateAsync(userModel);
                if (result.Succeeded)
                {
                    //create cookie
                    return RedirectToAction("Index", "Employee");
                }
                else
                {
                    foreach (var erroritem in result.Errors)
                    {
                        ModelState.AddModelError("Password", erroritem.Description);

                    }
                }
            }
            return View(newUserVM);
        }
    }
}
