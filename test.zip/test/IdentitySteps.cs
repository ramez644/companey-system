﻿/*
 * 
 * 1- install package mcrosoft.entity framework
 * 2-install identity entity framework
 * 3- create class application user inherit identity user
 * 4- change context enhiret from db context to identity context
 * 5-migration
 * 6-create accountcontroller
 * 7- 2 action registeration (get post)
 * 8- create view model register in class
 * 9- create register view 
 * 10- register service in program class  
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */